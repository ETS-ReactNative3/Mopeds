import React from 'react';
import ReactDOM from 'react-dom';
import MomsBuickApp from './MomsBuickApp';

ReactDOM.render(<MomsBuickApp />, document.getElementById('root'));
