import React, { Component } from 'react';
import SectionHeader from './components/SectionHeader';

export default class Customers extends Component {

  render() {
    return (
      <div>
        <SectionHeader title="Jobs" />
      </div>
    );
  }

}
